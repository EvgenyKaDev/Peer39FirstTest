package com.peer.testapp.controller.exception.constants;

public class Constants {
    public static String SOMETHING_WRONG = "Please check URL";
    public static String UNEXPECTED_EXTRACTION_ERROR = "Unexpected error during text extraction";

}
